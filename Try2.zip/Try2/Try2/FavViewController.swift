//
//  FavViewController.swift
//  Try2
//
//  Created by Apple Esprit on 31/10/2024.
//

import UIKit
import CoreData

class FavViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableview: UITableView!
    var milestones: [NSManagedObject] = []
 

    var item = ["Jaimie Lannister","Jon Snow", "Khal Drogo" , "Ned Stark"]
         var brandName = ["Jaimie Lannister","Jon Snow", "Khal Drogo" ,"Ned Stark"]
    
    func fetchData() {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let persistentContainer = appDelegate.persistentContainer
        let managedContext = persistentContainer.viewContext
        
        let request = NSFetchRequest<NSManagedObject>(entityName: "Entity")
        
        do {
            let resultReq = try managedContext.fetch(request)
            milestones = resultReq
            item = resultReq.compactMap { $0.value(forKey: "name") as? String }
        } catch {
            print("Fetch error: \(error.localizedDescription)")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
       
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mcelll", for: indexPath)
        let contentView = cell.contentView
        let itemLabel = contentView.viewWithTag(1) as! UILabel
        let itemImage = contentView.viewWithTag(2) as! UIImageView
        
        itemLabel.text = item[indexPath.row]
        itemImage.image = UIImage(named: item[indexPath.row]) // Assuming your image names match the items

        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let alert = UIAlertController(title: "Confirmation", message: "Voulez-vous supprimer cet élément ?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Annuler", style: .cancel))
            alert.addAction(UIAlertAction(title: "Supprimer", style: .destructive, handler: { [weak self] _ in
                guard let self = self else { return }
                
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                let context = appDelegate.persistentContainer.viewContext
                let objectToDelete = self.milestones[indexPath.row]
                
                context.delete(objectToDelete)
                do {
                    try context.save()
                    self.milestones.remove(at: indexPath.row)
                    self.item.remove(at: indexPath.row) // Also remove from items
                    self.tableview.deleteRows(at: [indexPath], with: .fade)
                } catch {
                    print("Échec de la suppression de l'élément: \(error.localizedDescription)")
                }
            }))
            self.present(alert, animated: true)
        }
    }
}

