//
//  DetailsViewController.swift
//  Try2
//
//  Created by Apple Esprit on 31/10/2024.
//

import UIKit
import CoreData

class DetailsViewController: UIViewController {
    
    var name:String?
  

    @IBOutlet weak var imageOutlet: UIImageView!
    
    @IBOutlet weak var NameOutlet: UILabel!

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //OnStart
        
        imageOutlet.image = UIImage(named: name!)
        NameOutlet.text = name!
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var faza1Outlet: UISlider!
    
    @IBOutlet weak var labelfaza1: UILabel!
    
    @IBOutlet weak var faza2label: UILabel!
    @IBOutlet weak var faza2Outlet: UISlider!
    @IBAction func faza2(_ sender: UISlider) {
        let score2 = Int(sender.value)
        faza2label.text = "\(score2)"

    }
    
    @IBAction func faza1(_ sender: UISlider) {
        
  
let score = Int(sender.value)
        labelfaza1.text = "\(score)"
    }
    
    @IBAction func fav(_ sender: Any) {
        guard let name = name else { return }

               // Check if the slider value is greater than 7
               if faza1Outlet.value > 7 {
                   if getByCreateria(name: name) {
                       let alert = UIAlertController(title: "BoxOffice", message: "Item already exists.", preferredStyle: .alert)
                       let action = UIAlertAction(title: "Got it!", style: .cancel, handler: nil)
                       alert.addAction(action)
                       self.present(alert, animated: true)
                   } else {
                       save()
                       let alert = UIAlertController(title: "BoxOffice", message: "Item saved successfully.", preferredStyle: .alert)
                       let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                       alert.addAction(action)
                       self.present(alert, animated: true)
                   }
               } else {
                   // Alert for weak value
                   let alert = UIAlertController(title: "BoxOffice", message: "Too weak to be the best.", preferredStyle: .alert)
                   let action = UIAlertAction(title: "Got it!", style: .cancel, handler: nil)
                   alert.addAction(action)
                   self.present(alert, animated: true)
               }
           }

           // FUNCTIONS

           func save() {
               let appDelegate = UIApplication.shared.delegate as! AppDelegate
               let persistentContainer = appDelegate.persistentContainer
               let managedContext = persistentContainer.viewContext
               
               let entityDescription = NSEntityDescription.entity(forEntityName: "Entity", in: managedContext)
               let object = NSManagedObject(entity: entityDescription!, insertInto: managedContext)
               
               object.setValue(name!, forKey: "name")
               
               do {
                   try managedContext.save()
                   print("Item saved successfully!")
               } catch {
                   print("Item insert error!")
               }
           }

           func getByCreateria(name: String) -> Bool {
               var movieExist = false
               
               let appDelegate = UIApplication.shared.delegate as! AppDelegate
               let persistentContainer = appDelegate.persistentContainer
               let managedContext = persistentContainer.viewContext
               
               let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Entity")
               let predicate = NSPredicate(format: "name = %@", name)
               request.predicate = predicate
               
               do {
                   let result = try managedContext.fetch(request)
                   if result.count > 0 {
                       movieExist = true
                       print("Shop exists!")
                   }
               } catch {
                   print("Fetching by criteria error!")
               }
               
               return movieExist
           }
       }
    
