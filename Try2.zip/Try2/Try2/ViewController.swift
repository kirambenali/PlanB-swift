//
//  ViewController.swift
//  Try2
//
//  Created by Apple Esprit on 31/10/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

