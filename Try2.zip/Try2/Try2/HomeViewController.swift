//
//  HomeViewController.swift
//  Try2
//
//  Created by Apple Esprit on 31/10/2024.
//

import UIKit

class HomeViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var item = ["Jaimie Lannister","Jon Snow", "Khal Drogo" , "Ned Stark"]
         var brandName = ["Jaimie Lannister","Jon Snow", "Khal Drogo" ,"Ned Stark"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        item.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mcell")
        let contentview = cell?.contentView
        let itemLabel = contentview?.viewWithTag(1) as! UILabel
        let itemImage = contentview?.viewWithTag(2) as! UIImageView
        itemLabel.text = brandName[indexPath.row]
        itemImage.image = UIImage(named:  item[indexPath.row])
        return cell!
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if segue.identifier == "msegue" {
            let param = sender  as! String
            let destination = segue.destination as! DetailsViewController
            destination.name = param
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let movie = item[indexPath.row]
        performSegue(withIdentifier: "msegue", sender: movie)
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
