//
//  FavViewController.swift
//  dabdoub
//
//  Created by Mac Mini 11 on 22/10/2024.
//

import UIKit
import CoreData

class FavViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
   


    var items =  [String]()
    
    func fetchData(){
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let persistantContainer = appDelegate.persistentContainer
               let managedContext = persistantContainer.viewContext
               
               let request = NSFetchRequest<NSManagedObject>(entityName: "Entity")
               do {
                  let resultReq =  try  managedContext.fetch(request)
                   for item in resultReq {
                       items.append(item.value(forKey: "name") as! String)
                       
                   }
                   
               } catch  {
                   print("fetch error")
               }
    }
    
  
 

    
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchData()
      
        
        // Do any additional setup after loading the view.
    }
    

    var milestonesImage = ["firstSmile", "FirstWord", "FirstSteps"]
    var milestones = ["First smile", "First word", "First steps"]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        milestonesImage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "mCell")
        let contentview = cell?.contentView
        let nameLabel = contentview?.viewWithTag(1) as! UILabel
        let itemImage = contentview?.viewWithTag(2) as! UIImageView
        nameLabel.text = "\(milestones[indexPath.row]) was"

        itemImage.image = UIImage(named: milestonesImage[indexPath.row])
        return cell!
    }
    

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */




    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
