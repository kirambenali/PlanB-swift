//
//  HomeViewController.swift
//  dabdoub
//
//  Created by Mac Mini 11 on 22/10/2024.
//

import UIKit

class HomeViewController: UIViewController ,UITableViewDataSource,UITableViewDelegate{
    
    var milestonesImage = ["firstSmile", "FirstWord", "FirstSteps"]
    var milestones = ["First smile", "First word", "First steps"]
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        milestonesImage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "mcell")
        let contentview = cell?.contentView
        let nameLabel = contentview?.viewWithTag(1) as! UILabel
        let itemImage = contentview?.viewWithTag(2) as! UIImageView
        nameLabel.text = milestones[indexPath.row]
        itemImage.image = UIImage(named: milestonesImage[indexPath.row])
        return cell!
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if segue.identifier == "msegue" {
            let param = sender as! String
            let destination = segue.destination as! DetailsViewController
            destination.name = param
        }
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let movie = milestonesImage[indexPath.row]
        performSegue(withIdentifier: "msegue", sender: movie)
        
    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
